'use strict'


var app = angular.module('silhouette', ['ui.router']);


app.config(function ($urlRouterProvider, $locationProvider) {
	$locationProvider.html5Mode({
	  enabled: true,
	  requireBase: false
	});
	$urlRouterProvider.otherwise('/');
});

//require('./login/index.js')(app)
window.thisApp = app;
console.log("GLOBAL APP: ", window.thisApp)

window.thisApp.run(['$state', '$rootScope', function ($state, $rootScope) {
	console.log('here')
	$state.go('login')
}])

console.log('dirname: ', __dirname)

require(__dirname + '/db')
require(__dirname + '/app/login')
require(__dirname + '/app/loggedIn')
require(__dirname + '/app/sidebar')
require(__dirname + '/app/signup')
require(__dirname + '/files')
require(__dirname + '/packages')
require(__dirname + '/apps')
require(__dirname + '/account')
require(__dirname + '/loggedIn.ctrl.js')
require(__dirname + '/loggedIn.state.js')
var mongoose = require('mongoose');
var File = mongoose.model('File');
var User = mongoose.model('User');
var Promise = require('bluebird');
var fs = Promise.promisifyAll(require("fs"));

window.thisApp.controller('LoggedInCtrl', function ($scope, $state, AccountEditFactory, FileManagerFactory, $rootScope) {

  $scope.saveAccountChanges = AccountEditFactory.saveUserChanges;

})



window.thisApp.config(function ($stateProvider) {
	$stateProvider.state('loggedIn', {
		templateUrl: __dirname + '/loggedIn.html',
		controller: 'FileManagerCtrl',
	})
	.state('loggedIn.account', {
		templateUrl: __dirname + '/account/account.html'
	})
	.state('loggedIn.fileManager', {
		templateUrl: __dirname + '/files/fileManager/fileManager.html',
	})
	.state('loggedIn.accountEdit', {
		templateUrl: __dirname + '/account/accountEdit.html'
	})
	.state('loggedIn.fileSelector', {
		templateUrl: __dirname + '/files/fileSelector/fileSelector.html',
	})
})
'use strict'
var Crypto = require('crypto')
var mongoose = require('mongoose');
var User = mongoose.model('User');

//@@ these are duplicates from models/user.js -- how can i share between these files
var encryptPassword = function(plainText, salt) {
	var hash = Crypto.createHash('sha1');
	hash.update(plainText);
	hash.update(salt);
	return hash.digest('hex');
};

var passwordMatches = function (testpass, userpass, salt) {
	return (encryptPassword(testpass, salt) === userpass) 
}


window.thisApp.factory('Auth', function ( $rootScope) {
	return {
		login: function (credentials) {
			return User.findOne({email: credentials.email})
			.then(function (user) {
				if(user && passwordMatches(credentials.password, user.password, user.salt)) {
	        //@@ should we establish session here?
	        $rootScope.currentUser = user;
	        return user;
				} else {
					var err = new Error('Not Authenticated')
					err.status = 401;
					throw err;
				}
			})
		},
		signup: function(userInfo){
			return User.findOne({email: userInfo.email})
			.then(function (findings) {
				if(findings === null) {
					var newUser = new User(userInfo);
					return newUser.save(function (err) {
						if (err) return err;
						return newUser.save();
					})
				} else {
					var err = new Error('User with that email already exists!')
					err.status = 401;
					throw err;
				}

			})
		}
	}
})
require(__dirname + '/login.ctrl.js')
require(__dirname + '/login.state.js')
require(__dirname + '/Auth.factory.js')
'use strict'

window.thisApp.controller('LoginCtrl', function (Auth, $scope, $state, $rootScope) {
	$scope.loginUser = function (userInfo) {
		Auth.login(userInfo)
		.then(function (loggedInUser) {
			console.log('Successful login!')
			$state.go('loggedIn.fileManager')
		})
		.catch (function (e) {
			console.log('error logging in', e)
		})
  };
})
'use strict'

window.thisApp.config(function ($stateProvider) {
	$stateProvider.state('login', {
		url: '/login',
		templateUrl: __dirname +'/login.html',
		controller: 'LoginCtrl'
	})
})
require(__dirname + '/sidebar.directive.js')
'use strict'

window.thisApp.directive('sidebar', function ($rootScope, $state) {
	return {
		restrict: 'E',
		templateUrl: __dirname + '/sidebar.html',
		link: function ($scope, element, attrs) {
			$scope.logout = function () {
				$rootScope.currentUser = null;
				$state.go('login')
			}
		}
	}
})
require(__dirname + '/signup.ctrl.js')
require(__dirname + '/signup.state.js')
'use strict'
console.log('ctrl', window.thisApp)
window.thisApp.controller('SignupCtrl', function (Auth, $scope, $state, $rootScope) {
	$scope.signupUser = function (userInfo) {
		Auth.signup(userInfo)
		.then(function () {
			return Auth.login(userInfo);
		})
		.then(function (loggedInUser) {
			console.log('Successful login!');
			$state.go('loggedIn.fileSelector');
		})
		.catch (function (e) {
			console.log('error logging in', e);
		})
	}
})

'use strict'
console.log('signup state')
window.thisApp.config(function ($stateProvider) {
	$stateProvider.state('signup', {
		url: '/signup',
		templateUrl: __dirname +'/signup.html',
		controller: 'SignupCtrl'
	})
})
var mongoose = require('mongoose');
//require(__dirname + '/db/models/user');
var User = mongoose.model('User');

window.thisApp.factory('AccountEditFactory', function($rootScope){
  return{
     saveUserChanges:function(){
        console.log('current User', $rootScope.currentUser);
        User.findByIdAndUpdate($rootScope.currentUser.id, {$set: $rootScope.currentUser}, {new:true})
        .then(null, function(err){
          throw err;
        });
      }
    }
})
require(__dirname + '/AccountEdit.factory.js')

require(__dirname + '/fileManager');
require(__dirname + '/fileSelector');
