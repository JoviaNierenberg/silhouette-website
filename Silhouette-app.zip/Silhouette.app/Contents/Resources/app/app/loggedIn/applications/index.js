require(__dirname + '/applicationManager')
require(__dirname + '/applicationSelector')
require(__dirname + '/applicationFactory.js')
require(__dirname + '/appList.js')