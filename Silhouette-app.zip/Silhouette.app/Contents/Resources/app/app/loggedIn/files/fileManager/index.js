require(__dirname + '/fileManagerFactory.js')
require(__dirname + '/fileManager.ctrl.js')
require(__dirname + '/customOnChangeDirective.js')
require(__dirname + '/previewPanel.directive.js')