window.thisApp.controller('PostInstallCheckCtrl', function ($scope){

})
