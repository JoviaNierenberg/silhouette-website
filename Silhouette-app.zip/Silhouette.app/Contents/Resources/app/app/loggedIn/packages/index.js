require(__dirname + '/packageSelector')
require(__dirname + '/packageFactory.js')
require(__dirname + '/moduleSelector')
require(__dirname + '/moduleManager')