require(__dirname + '/home.ctrl.js')
require(__dirname + '/home.factory.js')