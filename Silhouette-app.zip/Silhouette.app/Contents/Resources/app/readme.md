## Silhouette

## About
Hate keeping track of and setting up your development environment? So do we, so we made Silhouette!

- Use the buttons on the left to manage everything that is being tracked

- Click Set Up Environment to download your files, globally install modules and install applications to your applications folder

Enjoy!


## Dev

```
$ npm install
```

### Run

```
$ npm start
```

### Build

```
$ npm run build
```



## License

MIT © [Annie Cook, Anna Goldberg, Jovia Nierenberg](http://localhost:1337)
